English:

Source code of the Rassvet RP/Malinovka Bonus game server (latest version).

Correct server version: 0.3.7-R2

Reason for release: The project co-owner supports the war and cannot control his emotions.

Note: The CEF part of the server is located in the "Web" folder.


Russian:

Исходный код игрового сервера Rassvet RP/Malinovka Bonus (последняя версия).

Корректная версия сервера: 0.3.7-R2

Причина публикации: со-владелец проекта поддерживает войну и не может сдерживать свои эмоции.

Примечание: CEF-часть сервера находится в папке "Web".


Автор слива и разработчик -> https://vk.com/gitline


